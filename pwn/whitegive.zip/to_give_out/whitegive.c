#include <stdio.h>
#include <unistd.h>

void init_io()
{  
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main()
{
    unsigned long long num;

    init_io();
  
    printf("password:");
    scanf("%ld", &num);

    if (num == "paSsw0rd") { //Do you know strcmp?
        printf("you are right!\n");
        system("/bin/sh");
    } else {
        printf("sorry, you are wrong.\n");
    }


    return 0;
}