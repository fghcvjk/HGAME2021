#!/usr/bin/env python3

from Crypto.Util.number import getPrime
from libnum import s2n
from secret import messages


def RSA_encrypt(message):
    m = s2n(message)
    p = getPrime(2048)
    q = getPrime(2048)
    N = p * q
    e = 3
    c = pow(m, e, N)
    return N, e, c


for m in messages:
    N, e, c = RSA_encrypt(m)
    print("n = %s" % N)
    print("e = %s" % e)
    print("c = %s" % c)
