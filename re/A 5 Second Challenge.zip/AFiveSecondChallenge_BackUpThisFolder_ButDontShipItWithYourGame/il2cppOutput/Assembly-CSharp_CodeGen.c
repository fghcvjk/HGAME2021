﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Brick::Start()
extern void Brick_Start_m2D5DDEB4F633739743F4B5EA30E397FBF44E39CA (void);
// 0x00000002 System.Void Brick::OnMouseUp()
extern void Brick_OnMouseUp_m60131A103DFEEB727EF1CC540988484F15EBAB29 (void);
// 0x00000003 System.Void Brick::.ctor()
extern void Brick__ctor_m22FE4F3187637A692711D25603A07557B8CDEB75 (void);
// 0x00000004 System.Void BrickManager::Start()
extern void BrickManager_Start_mF44533BF69CBE4BD35CE39633DE800FC191D1F23 (void);
// 0x00000005 System.Void BrickManager::GenerateBricks()
extern void BrickManager_GenerateBricks_m0B644C8653C7A2E55CB8013C5C14D5A7918DDE81 (void);
// 0x00000006 System.Int32 BrickManager::CountNearby(System.Int32,System.Int32)
extern void BrickManager_CountNearby_m294C5F133BB90F880FF84145A9D12919FA4A803C (void);
// 0x00000007 System.Void BrickManager::ChangeSpriteByNearbyMineCount(System.Int32,System.Int32,System.Int32)
extern void BrickManager_ChangeSpriteByNearbyMineCount_m1400F97AF7F5948390F97097FC048174DDFDCF0E (void);
// 0x00000008 System.Void BrickManager::FloodFill(System.Int32,System.Int32,System.Boolean[0...,0...])
extern void BrickManager_FloodFill_m3AB32C7555BD6335218D9E416CEEC906740CA4CD (void);
// 0x00000009 System.Void BrickManager::.ctor()
extern void BrickManager__ctor_mF322252DA6A5B3596EE18B0E6AEA26EB4841A72A (void);
// 0x0000000A System.Void GameManager::Start()
extern void GameManager_Start_mD77CCDBF1DA8EC5C3AE7ED955DE4E7F54B79C88E (void);
// 0x0000000B System.Void GameManager::StartGame()
extern void GameManager_StartGame_mF6C4A4DD8F354D9A3FBC8925431C20B70BA0D8F8 (void);
// 0x0000000C System.Void GameManager::.ctor()
extern void GameManager__ctor_mF7F1107D38DE91EB8A57C1C3BB1A932C50CD9693 (void);
static Il2CppMethodPointer s_methodPointers[12] = 
{
	Brick_Start_m2D5DDEB4F633739743F4B5EA30E397FBF44E39CA,
	Brick_OnMouseUp_m60131A103DFEEB727EF1CC540988484F15EBAB29,
	Brick__ctor_m22FE4F3187637A692711D25603A07557B8CDEB75,
	BrickManager_Start_mF44533BF69CBE4BD35CE39633DE800FC191D1F23,
	BrickManager_GenerateBricks_m0B644C8653C7A2E55CB8013C5C14D5A7918DDE81,
	BrickManager_CountNearby_m294C5F133BB90F880FF84145A9D12919FA4A803C,
	BrickManager_ChangeSpriteByNearbyMineCount_m1400F97AF7F5948390F97097FC048174DDFDCF0E,
	BrickManager_FloodFill_m3AB32C7555BD6335218D9E416CEEC906740CA4CD,
	BrickManager__ctor_mF322252DA6A5B3596EE18B0E6AEA26EB4841A72A,
	GameManager_Start_mD77CCDBF1DA8EC5C3AE7ED955DE4E7F54B79C88E,
	GameManager_StartGame_mF6C4A4DD8F354D9A3FBC8925431C20B70BA0D8F8,
	GameManager__ctor_mF7F1107D38DE91EB8A57C1C3BB1A932C50CD9693,
};
static const int32_t s_InvokerIndices[12] = 
{
	23,
	23,
	23,
	23,
	23,
	56,
	38,
	565,
	23,
	23,
	23,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	12,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
