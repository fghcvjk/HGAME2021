﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// AFiveSecondChallenge.BombChecker
struct BombChecker_t6F78547653A30303197DE752136BFF107B035342;
// System.Double[0...,0...,0...]
struct DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429;

IL2CPP_EXTERN_C RuntimeClass* BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_tCB52E996C21085BE0E0BA4A8C1CBD072FE5B869E____CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0_FieldInfo_var;
IL2CPP_EXTERN_C const uint32_t BombChecker_CheckBombAt_m9F78BC9850D32E107CBE581DFE3DD26BE10F2CAC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BombChecker__cctor_m6B9F38A98234228359E8B81B6B1200C9A7A3DB14_MetadataUsageId;

struct DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tE22CA9513A218A0B7922869666384F9BBDEE16ED 
{
public:

public:
};


// System.Object

struct Il2CppArrayBounds;

// System.Array


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// <PrivateImplementationDetails>___StaticArrayInitTypeSizeU3D16200
struct  __StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88__padding[16200];
	};

public:
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.DateTime
struct  DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 
{
public:
	// System.UInt64 System.DateTime::dateData
	uint64_t ___dateData_44;

public:
	inline static int32_t get_offset_of_dateData_44() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132, ___dateData_44)); }
	inline uint64_t get_dateData_44() const { return ___dateData_44; }
	inline uint64_t* get_address_of_dateData_44() { return &___dateData_44; }
	inline void set_dateData_44(uint64_t value)
	{
		___dateData_44 = value;
	}
};

struct DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields
{
public:
	// System.Int32[] System.DateTime::DaysToMonth365
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___DaysToMonth365_29;
	// System.Int32[] System.DateTime::DaysToMonth366
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___DaysToMonth366_30;
	// System.DateTime System.DateTime::MinValue
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___MinValue_31;
	// System.DateTime System.DateTime::MaxValue
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___MaxValue_32;

public:
	inline static int32_t get_offset_of_DaysToMonth365_29() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___DaysToMonth365_29)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_DaysToMonth365_29() const { return ___DaysToMonth365_29; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_DaysToMonth365_29() { return &___DaysToMonth365_29; }
	inline void set_DaysToMonth365_29(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___DaysToMonth365_29 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DaysToMonth365_29), (void*)value);
	}

	inline static int32_t get_offset_of_DaysToMonth366_30() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___DaysToMonth366_30)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_DaysToMonth366_30() const { return ___DaysToMonth366_30; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_DaysToMonth366_30() { return &___DaysToMonth366_30; }
	inline void set_DaysToMonth366_30(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___DaysToMonth366_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DaysToMonth366_30), (void*)value);
	}

	inline static int32_t get_offset_of_MinValue_31() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___MinValue_31)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_MinValue_31() const { return ___MinValue_31; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_MinValue_31() { return &___MinValue_31; }
	inline void set_MinValue_31(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___MinValue_31 = value;
	}

	inline static int32_t get_offset_of_MaxValue_32() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___MaxValue_32)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_MaxValue_32() const { return ___MaxValue_32; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_MaxValue_32() { return &___MaxValue_32; }
	inline void set_MaxValue_32(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___MaxValue_32 = value;
	}
};


// System.Double
struct  Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Int64
struct  Int64_t7A386C2FF7B0280A0F516992401DDFCF0FF7B436 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t7A386C2FF7B0280A0F516992401DDFCF0FF7B436, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_tCB52E996C21085BE0E0BA4A8C1CBD072FE5B869E  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tCB52E996C21085BE0E0BA4A8C1CBD072FE5B869E_StaticFields
{
public:
	// <PrivateImplementationDetails>___StaticArrayInitTypeSizeU3D16200 <PrivateImplementationDetails>::CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E
	__StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88  ___CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0;

public:
	inline static int32_t get_offset_of_CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCB52E996C21085BE0E0BA4A8C1CBD072FE5B869E_StaticFields, ___CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0)); }
	inline __StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88  get_CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0() const { return ___CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0; }
	inline __StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88 * get_address_of_CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0() { return &___CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0; }
	inline void set_CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0(__StaticArrayInitTypeSizeU3D16200_t1319562077CA3AB53A7309DC61AC937637E81D88  value)
	{
		___CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0 = value;
	}
};


// System.DateTimeOffset
struct  DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85 
{
public:
	// System.DateTime System.DateTimeOffset::m_dateTime
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___m_dateTime_2;
	// System.Int16 System.DateTimeOffset::m_offsetMinutes
	int16_t ___m_offsetMinutes_3;

public:
	inline static int32_t get_offset_of_m_dateTime_2() { return static_cast<int32_t>(offsetof(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85, ___m_dateTime_2)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_m_dateTime_2() const { return ___m_dateTime_2; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_m_dateTime_2() { return &___m_dateTime_2; }
	inline void set_m_dateTime_2(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___m_dateTime_2 = value;
	}

	inline static int32_t get_offset_of_m_offsetMinutes_3() { return static_cast<int32_t>(offsetof(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85, ___m_offsetMinutes_3)); }
	inline int16_t get_m_offsetMinutes_3() const { return ___m_offsetMinutes_3; }
	inline int16_t* get_address_of_m_offsetMinutes_3() { return &___m_offsetMinutes_3; }
	inline void set_m_offsetMinutes_3(int16_t value)
	{
		___m_offsetMinutes_3 = value;
	}
};

struct DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85_StaticFields
{
public:
	// System.DateTimeOffset System.DateTimeOffset::MinValue
	DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  ___MinValue_0;
	// System.DateTimeOffset System.DateTimeOffset::MaxValue
	DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  ___MaxValue_1;

public:
	inline static int32_t get_offset_of_MinValue_0() { return static_cast<int32_t>(offsetof(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85_StaticFields, ___MinValue_0)); }
	inline DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  get_MinValue_0() const { return ___MinValue_0; }
	inline DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85 * get_address_of_MinValue_0() { return &___MinValue_0; }
	inline void set_MinValue_0(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  value)
	{
		___MinValue_0 = value;
	}

	inline static int32_t get_offset_of_MaxValue_1() { return static_cast<int32_t>(offsetof(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85_StaticFields, ___MaxValue_1)); }
	inline DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  get_MaxValue_1() const { return ___MaxValue_1; }
	inline DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85 * get_address_of_MaxValue_1() { return &___MaxValue_1; }
	inline void set_MaxValue_1(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  value)
	{
		___MaxValue_1 = value;
	}
};


// System.RuntimeFieldHandle
struct  RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF 
{
public:
	// System.IntPtr System.RuntimeFieldHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};


// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};


// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};


// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};


// AFiveSecondChallenge.BombChecker
struct  BombChecker_t6F78547653A30303197DE752136BFF107B035342  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

struct BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields
{
public:
	// System.Int64 AFiveSecondChallenge.BombChecker::firstQueryTime
	int64_t ___firstQueryTime_4;
	// System.Int32 AFiveSecondChallenge.BombChecker::expireIn
	int32_t ___expireIn_5;
	// System.Double[0...,0...,0...] AFiveSecondChallenge.BombChecker::matrix
	DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* ___matrix_6;

public:
	inline static int32_t get_offset_of_firstQueryTime_4() { return static_cast<int32_t>(offsetof(BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields, ___firstQueryTime_4)); }
	inline int64_t get_firstQueryTime_4() const { return ___firstQueryTime_4; }
	inline int64_t* get_address_of_firstQueryTime_4() { return &___firstQueryTime_4; }
	inline void set_firstQueryTime_4(int64_t value)
	{
		___firstQueryTime_4 = value;
	}

	inline static int32_t get_offset_of_expireIn_5() { return static_cast<int32_t>(offsetof(BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields, ___expireIn_5)); }
	inline int32_t get_expireIn_5() const { return ___expireIn_5; }
	inline int32_t* get_address_of_expireIn_5() { return &___expireIn_5; }
	inline void set_expireIn_5(int32_t value)
	{
		___expireIn_5 = value;
	}

	inline static int32_t get_offset_of_matrix_6() { return static_cast<int32_t>(offsetof(BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields, ___matrix_6)); }
	inline DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* get_matrix_6() const { return ___matrix_6; }
	inline DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D** get_address_of_matrix_6() { return &___matrix_6; }
	inline void set_matrix_6(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* value)
	{
		___matrix_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___matrix_6), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Double[,,]
struct DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) double m_Items[1];

public:
	inline double GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline double* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, double value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline double GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline double* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, double value)
	{
		m_Items[index] = value;
	}
	inline double GetAt(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k) const
	{
		il2cpp_array_size_t iBound = bounds[0].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(i, iBound);
		il2cpp_array_size_t jBound = bounds[1].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(j, jBound);
		il2cpp_array_size_t kBound = bounds[2].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(k, kBound);

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		return m_Items[index];
	}
	inline double* GetAddressAt(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k)
	{
		il2cpp_array_size_t iBound = bounds[0].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(i, iBound);
		il2cpp_array_size_t jBound = bounds[1].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(j, jBound);
		il2cpp_array_size_t kBound = bounds[2].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(k, kBound);

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k, double value)
	{
		il2cpp_array_size_t iBound = bounds[0].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(i, iBound);
		il2cpp_array_size_t jBound = bounds[1].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(j, jBound);
		il2cpp_array_size_t kBound = bounds[2].length;
		IL2CPP_ARRAY_BOUNDS_CHECK(k, kBound);

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		m_Items[index] = value;
	}
	inline double GetAtUnchecked(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k) const
	{
		il2cpp_array_size_t jBound = bounds[1].length;
		il2cpp_array_size_t kBound = bounds[2].length;

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		return m_Items[index];
	}
	inline double* GetAddressAtUnchecked(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k)
	{
		il2cpp_array_size_t jBound = bounds[1].length;
		il2cpp_array_size_t kBound = bounds[2].length;

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t i, il2cpp_array_size_t j, il2cpp_array_size_t k, double value)
	{
		il2cpp_array_size_t jBound = bounds[1].length;
		il2cpp_array_size_t kBound = bounds[2].length;

		il2cpp_array_size_t index = (i * jBound + j) * kBound + k;
		m_Items[index] = value;
	}
};



// System.DateTimeOffset System.DateTimeOffset::get_Now()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  DateTimeOffset_get_Now_mB50A645DA5F2A946FB7CF6BC49C37C8965E4626D (const RuntimeMethod* method);
// System.Int64 System.DateTimeOffset::ToUnixTimeSeconds()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int64_t DateTimeOffset_ToUnixTimeSeconds_m6B0B5DE0F1C36318D62AF9284BD52F222C586A7C (DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85 * __this, const RuntimeMethod* method);
// System.Int64 AFiveSecondChallenge.BombChecker::GetNowUnixTime()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int64_t BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8 (const RuntimeMethod* method);
// System.Boolean AFiveSecondChallenge.BombChecker::CheckIfExpired()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E (const RuntimeMethod* method);
// System.Void UnityEngine.MonoBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_mEAEC84B222C60319D593E456D769B3311DFCEF97 (MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.RuntimeHelpers::InitializeArray(System.Array,System.RuntimeFieldHandle)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RuntimeHelpers_InitializeArray_m29F50CDFEEE0AB868200291366253DD4737BC76A (RuntimeArray * ___array0, RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF  ___fldHandle1, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int64 AFiveSecondChallenge.BombChecker::GetNowUnixTime()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int64_t BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		IL2CPP_RUNTIME_CLASS_INIT(DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85_il2cpp_TypeInfo_var);
		DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85  L_0 = DateTimeOffset_get_Now_mB50A645DA5F2A946FB7CF6BC49C37C8965E4626D(/*hidden argument*/NULL);
		V_0 = L_0;
		int64_t L_1 = DateTimeOffset_ToUnixTimeSeconds_m6B0B5DE0F1C36318D62AF9284BD52F222C586A7C((DateTimeOffset_t6C333873402CAD576160B4F8E159EB6834F06B85 *)(&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean AFiveSecondChallenge.BombChecker::CheckIfExpired()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		int64_t L_0 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_firstQueryTime_4();
		if (!L_0)
		{
			goto IL_001b;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		int64_t L_1 = BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8(/*hidden argument*/NULL);
		int64_t L_2 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_firstQueryTime_4();
		int32_t L_3 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_expireIn_5();
		return (bool)((((int64_t)((int64_t)il2cpp_codegen_subtract((int64_t)L_1, (int64_t)L_2))) > ((int64_t)(((int64_t)((int64_t)L_3)))))? 1 : 0);
	}

IL_001b:
	{
		return (bool)0;
	}
}
// System.Boolean AFiveSecondChallenge.BombChecker::CheckBombAt(UnityEngine.Vector2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BombChecker_CheckBombAt_m9F78BC9850D32E107CBE581DFE3DD26BE10F2CAC (Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___vec0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BombChecker_CheckBombAt_m9F78BC9850D32E107CBE581DFE3DD26BE10F2CAC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	double V_2 = 0.0;
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		int64_t L_0 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_firstQueryTime_4();
		if (L_0)
		{
			goto IL_0013;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		int64_t L_1 = BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8(/*hidden argument*/NULL);
		((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->set_firstQueryTime_4(L_1);
		goto IL_001c;
	}

IL_0013:
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		bool L_2 = BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E(/*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_001c;
		}
	}
	{
		return (bool)1;
	}

IL_001c:
	{
		IL2CPP_RUNTIME_CLASS_INIT(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var);
		DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* L_3 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_matrix_6();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_4 = ___vec0;
		float L_5 = L_4.get_y_1();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_6 = ___vec0;
		float L_7 = L_6.get_x_0();
		NullCheck((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_3);
		double L_8 = ((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_3)->GetAt((((int32_t)((int32_t)L_5))), ((int32_t)((int32_t)(((int32_t)((int32_t)L_7)))/(int32_t)3)), 0);
		DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* L_9 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_matrix_6();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_10 = ___vec0;
		float L_11 = L_10.get_y_1();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_12 = ___vec0;
		float L_13 = L_12.get_x_0();
		NullCheck((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_9);
		double L_14 = ((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_9)->GetAt((((int32_t)((int32_t)L_11))), ((int32_t)((int32_t)(((int32_t)((int32_t)L_13)))/(int32_t)3)), 1);
		V_0 = L_14;
		DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* L_15 = ((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->get_matrix_6();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_16 = ___vec0;
		float L_17 = L_16.get_y_1();
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_18 = ___vec0;
		float L_19 = L_18.get_x_0();
		NullCheck((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_15);
		double L_20 = ((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_15)->GetAt((((int32_t)((int32_t)L_17))), ((int32_t)((int32_t)(((int32_t)((int32_t)L_19)))/(int32_t)3)), 2);
		V_1 = L_20;
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_21 = ___vec0;
		float L_22 = L_21.get_x_0();
		V_2 = (((double)((double)((float)il2cpp_codegen_subtract((float)(fmodf(L_22, (3.0f))), (float)(1.0f))))));
		double L_23 = V_2;
		double L_24 = V_2;
		double L_25 = V_0;
		double L_26 = V_2;
		double L_27 = V_1;
		return (bool)((((double)((double)il2cpp_codegen_add((double)((double)il2cpp_codegen_add((double)((double)il2cpp_codegen_multiply((double)((double)il2cpp_codegen_multiply((double)L_8, (double)L_23)), (double)L_24)), (double)((double)il2cpp_codegen_multiply((double)L_25, (double)L_26)))), (double)L_27))) > ((double)(0.0)))? 1 : 0);
	}
}
// System.Void AFiveSecondChallenge.BombChecker::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BombChecker__ctor_m49ACCAFFE3DA3021B4D9B7231B207F9AF2CF4308 (BombChecker_t6F78547653A30303197DE752136BFF107B035342 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_mEAEC84B222C60319D593E456D769B3311DFCEF97(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void AFiveSecondChallenge.BombChecker::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BombChecker__cctor_m6B9F38A98234228359E8B81B6B1200C9A7A3DB14 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BombChecker__cctor_m6B9F38A98234228359E8B81B6B1200C9A7A3DB14_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->set_firstQueryTime_4((((int64_t)((int64_t)0))));
		((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->set_expireIn_5(5);
		il2cpp_array_size_t L_1[] = { (il2cpp_array_size_t)((int32_t)45), (il2cpp_array_size_t)((int32_t)15), (il2cpp_array_size_t)3 };
		DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* L_0 = (DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)GenArrayNew(DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D_il2cpp_TypeInfo_var, L_1);
		DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D* L_2 = L_0;
		RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF  L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_tCB52E996C21085BE0E0BA4A8C1CBD072FE5B869E____CDA176AF97A482BE8C44E79A93DEF0EC45B7F154FCD525D932AC5596D9E47C4E_0_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m29F50CDFEEE0AB868200291366253DD4737BC76A((RuntimeArray *)(RuntimeArray *)L_2, L_3, /*hidden argument*/NULL);
		((BombChecker_t6F78547653A30303197DE752136BFF107B035342_StaticFields*)il2cpp_codegen_static_fields_for(BombChecker_t6F78547653A30303197DE752136BFF107B035342_il2cpp_TypeInfo_var))->set_matrix_6((DoubleU5BU2CU2CU5D_t52D90E91F26D35646AF02F1D1DF3770A40CD9B7D*)L_2);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
