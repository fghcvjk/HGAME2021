﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Exception System.Linq.Error::ArgumentNull(System.String)
extern void Error_ArgumentNull_mCA126ED8F4F3B343A70E201C44B3A509690F1EA7 (void);
// 0x00000002 System.Exception System.Linq.Error::MoreThanOneMatch()
extern void Error_MoreThanOneMatch_m85C3617F782E9F2333FC1FDF42821BE069F24623 (void);
// 0x00000003 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::Where(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000004 System.Func`2<TSource,System.Boolean> System.Linq.Enumerable::CombinePredicates(System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,System.Boolean>)
// 0x00000005 TSource System.Linq.Enumerable::SingleOrDefault(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000006 System.Boolean System.Linq.Enumerable::Any(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000007 System.Boolean System.Linq.Enumerable::Any(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000008 System.Void System.Linq.Enumerable_Iterator`1::.ctor()
// 0x00000009 TSource System.Linq.Enumerable_Iterator`1::get_Current()
// 0x0000000A System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_Iterator`1::Clone()
// 0x0000000B System.Void System.Linq.Enumerable_Iterator`1::Dispose()
// 0x0000000C System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable_Iterator`1::GetEnumerator()
// 0x0000000D System.Boolean System.Linq.Enumerable_Iterator`1::MoveNext()
// 0x0000000E System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_Iterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x0000000F System.Object System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerator.get_Current()
// 0x00000010 System.Collections.IEnumerator System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000011 System.Void System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerator.Reset()
// 0x00000012 System.Void System.Linq.Enumerable_WhereEnumerableIterator`1::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000013 System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereEnumerableIterator`1::Clone()
// 0x00000014 System.Void System.Linq.Enumerable_WhereEnumerableIterator`1::Dispose()
// 0x00000015 System.Boolean System.Linq.Enumerable_WhereEnumerableIterator`1::MoveNext()
// 0x00000016 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereEnumerableIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x00000017 System.Void System.Linq.Enumerable_WhereArrayIterator`1::.ctor(TSource[],System.Func`2<TSource,System.Boolean>)
// 0x00000018 System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereArrayIterator`1::Clone()
// 0x00000019 System.Boolean System.Linq.Enumerable_WhereArrayIterator`1::MoveNext()
// 0x0000001A System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereArrayIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x0000001B System.Void System.Linq.Enumerable_WhereListIterator`1::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x0000001C System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereListIterator`1::Clone()
// 0x0000001D System.Boolean System.Linq.Enumerable_WhereListIterator`1::MoveNext()
// 0x0000001E System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereListIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x0000001F System.Void System.Linq.Enumerable_<>c__DisplayClass6_0`1::.ctor()
// 0x00000020 System.Boolean System.Linq.Enumerable_<>c__DisplayClass6_0`1::<CombinePredicates>b__0(TSource)
// 0x00000021 System.Void System.Collections.Generic.HashSet`1::.ctor()
// 0x00000022 System.Void System.Collections.Generic.HashSet`1::.ctor(System.Collections.Generic.IEqualityComparer`1<T>)
// 0x00000023 System.Void System.Collections.Generic.HashSet`1::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x00000024 System.Void System.Collections.Generic.HashSet`1::System.Collections.Generic.ICollection<T>.Add(T)
// 0x00000025 System.Void System.Collections.Generic.HashSet`1::Clear()
// 0x00000026 System.Boolean System.Collections.Generic.HashSet`1::Contains(T)
// 0x00000027 System.Void System.Collections.Generic.HashSet`1::CopyTo(T[],System.Int32)
// 0x00000028 System.Boolean System.Collections.Generic.HashSet`1::Remove(T)
// 0x00000029 System.Int32 System.Collections.Generic.HashSet`1::get_Count()
// 0x0000002A System.Boolean System.Collections.Generic.HashSet`1::System.Collections.Generic.ICollection<T>.get_IsReadOnly()
// 0x0000002B System.Collections.Generic.HashSet`1_Enumerator<T> System.Collections.Generic.HashSet`1::GetEnumerator()
// 0x0000002C System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.HashSet`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x0000002D System.Collections.IEnumerator System.Collections.Generic.HashSet`1::System.Collections.IEnumerable.GetEnumerator()
// 0x0000002E System.Void System.Collections.Generic.HashSet`1::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000002F System.Void System.Collections.Generic.HashSet`1::OnDeserialization(System.Object)
// 0x00000030 System.Boolean System.Collections.Generic.HashSet`1::Add(T)
// 0x00000031 System.Void System.Collections.Generic.HashSet`1::CopyTo(T[])
// 0x00000032 System.Void System.Collections.Generic.HashSet`1::CopyTo(T[],System.Int32,System.Int32)
// 0x00000033 System.Void System.Collections.Generic.HashSet`1::Initialize(System.Int32)
// 0x00000034 System.Void System.Collections.Generic.HashSet`1::IncreaseCapacity()
// 0x00000035 System.Void System.Collections.Generic.HashSet`1::SetCapacity(System.Int32)
// 0x00000036 System.Boolean System.Collections.Generic.HashSet`1::AddIfNotPresent(T)
// 0x00000037 System.Int32 System.Collections.Generic.HashSet`1::InternalGetHashCode(T)
// 0x00000038 System.Void System.Collections.Generic.HashSet`1_Enumerator::.ctor(System.Collections.Generic.HashSet`1<T>)
// 0x00000039 System.Void System.Collections.Generic.HashSet`1_Enumerator::Dispose()
// 0x0000003A System.Boolean System.Collections.Generic.HashSet`1_Enumerator::MoveNext()
// 0x0000003B T System.Collections.Generic.HashSet`1_Enumerator::get_Current()
// 0x0000003C System.Object System.Collections.Generic.HashSet`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x0000003D System.Void System.Collections.Generic.HashSet`1_Enumerator::System.Collections.IEnumerator.Reset()
static Il2CppMethodPointer s_methodPointers[61] = 
{
	Error_ArgumentNull_mCA126ED8F4F3B343A70E201C44B3A509690F1EA7,
	Error_MoreThanOneMatch_m85C3617F782E9F2333FC1FDF42821BE069F24623,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
static const int32_t s_InvokerIndices[61] = 
{
	0,
	4,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
};
static const Il2CppTokenRangePair s_rgctxIndices[12] = 
{
	{ 0x02000004, { 22, 4 } },
	{ 0x02000005, { 26, 9 } },
	{ 0x02000006, { 35, 7 } },
	{ 0x02000007, { 42, 10 } },
	{ 0x02000008, { 52, 1 } },
	{ 0x02000009, { 53, 21 } },
	{ 0x0200000B, { 74, 2 } },
	{ 0x06000003, { 0, 10 } },
	{ 0x06000004, { 10, 5 } },
	{ 0x06000005, { 15, 3 } },
	{ 0x06000006, { 18, 1 } },
	{ 0x06000007, { 19, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[76] = 
{
	{ (Il2CppRGCTXDataType)2, 16236 },
	{ (Il2CppRGCTXDataType)3, 11710 },
	{ (Il2CppRGCTXDataType)2, 16237 },
	{ (Il2CppRGCTXDataType)2, 16238 },
	{ (Il2CppRGCTXDataType)3, 11711 },
	{ (Il2CppRGCTXDataType)2, 16239 },
	{ (Il2CppRGCTXDataType)2, 16240 },
	{ (Il2CppRGCTXDataType)3, 11712 },
	{ (Il2CppRGCTXDataType)2, 16241 },
	{ (Il2CppRGCTXDataType)3, 11713 },
	{ (Il2CppRGCTXDataType)2, 16242 },
	{ (Il2CppRGCTXDataType)3, 11714 },
	{ (Il2CppRGCTXDataType)3, 11715 },
	{ (Il2CppRGCTXDataType)2, 12927 },
	{ (Il2CppRGCTXDataType)3, 11716 },
	{ (Il2CppRGCTXDataType)2, 12929 },
	{ (Il2CppRGCTXDataType)2, 16243 },
	{ (Il2CppRGCTXDataType)3, 11717 },
	{ (Il2CppRGCTXDataType)2, 12932 },
	{ (Il2CppRGCTXDataType)2, 12934 },
	{ (Il2CppRGCTXDataType)2, 16244 },
	{ (Il2CppRGCTXDataType)3, 11718 },
	{ (Il2CppRGCTXDataType)3, 11719 },
	{ (Il2CppRGCTXDataType)3, 11720 },
	{ (Il2CppRGCTXDataType)2, 12939 },
	{ (Il2CppRGCTXDataType)3, 11721 },
	{ (Il2CppRGCTXDataType)3, 11722 },
	{ (Il2CppRGCTXDataType)2, 12948 },
	{ (Il2CppRGCTXDataType)2, 16245 },
	{ (Il2CppRGCTXDataType)3, 11723 },
	{ (Il2CppRGCTXDataType)3, 11724 },
	{ (Il2CppRGCTXDataType)2, 12950 },
	{ (Il2CppRGCTXDataType)2, 16135 },
	{ (Il2CppRGCTXDataType)3, 11725 },
	{ (Il2CppRGCTXDataType)3, 11726 },
	{ (Il2CppRGCTXDataType)3, 11727 },
	{ (Il2CppRGCTXDataType)2, 12957 },
	{ (Il2CppRGCTXDataType)2, 16246 },
	{ (Il2CppRGCTXDataType)3, 11728 },
	{ (Il2CppRGCTXDataType)3, 11729 },
	{ (Il2CppRGCTXDataType)3, 10669 },
	{ (Il2CppRGCTXDataType)3, 11730 },
	{ (Il2CppRGCTXDataType)3, 11731 },
	{ (Il2CppRGCTXDataType)2, 12966 },
	{ (Il2CppRGCTXDataType)2, 16247 },
	{ (Il2CppRGCTXDataType)3, 11732 },
	{ (Il2CppRGCTXDataType)3, 11733 },
	{ (Il2CppRGCTXDataType)3, 11734 },
	{ (Il2CppRGCTXDataType)3, 11735 },
	{ (Il2CppRGCTXDataType)3, 11736 },
	{ (Il2CppRGCTXDataType)3, 10675 },
	{ (Il2CppRGCTXDataType)3, 11737 },
	{ (Il2CppRGCTXDataType)3, 11738 },
	{ (Il2CppRGCTXDataType)3, 11739 },
	{ (Il2CppRGCTXDataType)2, 16248 },
	{ (Il2CppRGCTXDataType)3, 11740 },
	{ (Il2CppRGCTXDataType)3, 11741 },
	{ (Il2CppRGCTXDataType)3, 11742 },
	{ (Il2CppRGCTXDataType)2, 12980 },
	{ (Il2CppRGCTXDataType)3, 11743 },
	{ (Il2CppRGCTXDataType)3, 11744 },
	{ (Il2CppRGCTXDataType)2, 12983 },
	{ (Il2CppRGCTXDataType)3, 11745 },
	{ (Il2CppRGCTXDataType)1, 16249 },
	{ (Il2CppRGCTXDataType)2, 12982 },
	{ (Il2CppRGCTXDataType)3, 11746 },
	{ (Il2CppRGCTXDataType)1, 12982 },
	{ (Il2CppRGCTXDataType)1, 12980 },
	{ (Il2CppRGCTXDataType)2, 16250 },
	{ (Il2CppRGCTXDataType)2, 12982 },
	{ (Il2CppRGCTXDataType)3, 11747 },
	{ (Il2CppRGCTXDataType)3, 11748 },
	{ (Il2CppRGCTXDataType)3, 11749 },
	{ (Il2CppRGCTXDataType)2, 12981 },
	{ (Il2CppRGCTXDataType)3, 11750 },
	{ (Il2CppRGCTXDataType)2, 12994 },
};
extern const Il2CppCodeGenModule g_System_CoreCodeGenModule;
const Il2CppCodeGenModule g_System_CoreCodeGenModule = 
{
	"System.Core.dll",
	61,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	12,
	s_rgctxIndices,
	76,
	s_rgctxValues,
	NULL,
};
