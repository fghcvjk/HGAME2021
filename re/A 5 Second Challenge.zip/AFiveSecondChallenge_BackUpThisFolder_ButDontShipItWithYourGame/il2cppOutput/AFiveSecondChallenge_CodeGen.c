﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Int64 AFiveSecondChallenge.BombChecker::GetNowUnixTime()
extern void BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8 (void);
// 0x00000002 System.Boolean AFiveSecondChallenge.BombChecker::CheckIfExpired()
extern void BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E (void);
// 0x00000003 System.Boolean AFiveSecondChallenge.BombChecker::CheckBombAt(UnityEngine.Vector2)
extern void BombChecker_CheckBombAt_m9F78BC9850D32E107CBE581DFE3DD26BE10F2CAC (void);
// 0x00000004 System.Void AFiveSecondChallenge.BombChecker::.ctor()
extern void BombChecker__ctor_m49ACCAFFE3DA3021B4D9B7231B207F9AF2CF4308 (void);
// 0x00000005 System.Void AFiveSecondChallenge.BombChecker::.cctor()
extern void BombChecker__cctor_m6B9F38A98234228359E8B81B6B1200C9A7A3DB14 (void);
static Il2CppMethodPointer s_methodPointers[5] = 
{
	BombChecker_GetNowUnixTime_m02658B00EEC2CD986B3894FB392B39BB186716A8,
	BombChecker_CheckIfExpired_m11965D79AB8C709FB9F999ACFFA108438A43652E,
	BombChecker_CheckBombAt_m9F78BC9850D32E107CBE581DFE3DD26BE10F2CAC,
	BombChecker__ctor_m49ACCAFFE3DA3021B4D9B7231B207F9AF2CF4308,
	BombChecker__cctor_m6B9F38A98234228359E8B81B6B1200C9A7A3DB14,
};
static const int32_t s_InvokerIndices[5] = 
{
	118,
	49,
	1549,
	23,
	3,
};
extern const Il2CppCodeGenModule g_AFiveSecondChallengeCodeGenModule;
const Il2CppCodeGenModule g_AFiveSecondChallengeCodeGenModule = 
{
	"AFiveSecondChallenge.dll",
	5,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
